create database db01;
use db01;
create table person(
    name varchar(255),
    age int
);